def calculate_budget(base_object, material_cost):
    # Implementar o cálculo do orçamento aqui
    pass